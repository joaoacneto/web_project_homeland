Tripleten Sprint 5 - Project Homeland
Autor: Joao Aloysio Carvalho Neto
Projeto: Criação de um site que se adapta conforme o tamanho da tela. 1280px para monitor de desktop, 768px para tablet e 320px para celular.
Tecnologia nova usada foi a de usar o @font-face e o @media para fazer o site se adaptar às telas de diferentes tamanhos.
Github pages: https://joaoacneto.github.io/web_project_homeland/
